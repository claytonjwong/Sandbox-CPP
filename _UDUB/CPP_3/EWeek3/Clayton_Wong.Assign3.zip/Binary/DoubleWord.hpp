//
//  DoubleWord.hpp
//  EWeek3
//
//  Created by CLAYTON WONG on 8/9/18.
//  Copyright © 2018 Clayton Wong. All rights reserved.
//

#pragma once

#include "MultiByte_t.hpp"

namespace Binary
{
    using DoubleWord = MultiByte_t<uint32_t>;
}
