//
//  Conversion.hpp
//  EWeek5
//
//  Created by Clayton Wong on 9/16/18.
//  Copyright © 2018 Clayton Wong. All rights reserved.
//

#pragma once

#include <sstream>

namespace Utility
{
    int toInt ( const std::string& str );
    
} // namespace Utility
