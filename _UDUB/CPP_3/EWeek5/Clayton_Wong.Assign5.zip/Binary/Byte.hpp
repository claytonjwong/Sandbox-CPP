//
//  Byte.hpp
//  EWeek3
//
//  Created by CLAYTON WONG on 8/7/18.
//  Copyright © 2018 Clayton Wong. All rights reserved.
//

#pragma once

#include "Binary_t.hpp"

namespace Binary
{
    using Byte = Binary_t<Byte_t>;
}

